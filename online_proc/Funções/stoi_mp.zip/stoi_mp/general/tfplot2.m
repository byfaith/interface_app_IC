function tfplot2(a1, a2, a3, a4, a5)

if nargin==1
    X   = a1;
    imagesc(X);
%     xind = 1:size(xind, 1);
%     yind = 1:size(xind, 1);
elseif nargin==3
    X   = a1;
    if length(a2)>1
        
        xind    = a1;
        yind    = a2;
        X       = a3;
        imagesc(yind, xind, X);
    else
    	mn  = a2;
        mx  = a3;
        imagesc(X, [mn mx]);
    end
       

else
	xind    = a1;
    yind    = a2;
	X       = a3;
    mn      = a4;
    mx      = a5;
    imagesc(yind, xind, X, [mn mx]);
end

set(gca,'YDir','normal');
colorbar;