function [y Y_bin X Y Yr] = stoi_mp(x, fs_signal, num_sin)
% function [y Y_bin X Y Yr] = stoi_mp(x, fs, num_sin)
%
% This function applies a CI-simulator based on a sinusoidal vocoder to the
% speech signal 'x' and applies a channel-selection strategy based on 
% matching pursuit as described in [1]. See [1] for more details on the
% algorithm.
%
% input parameters:
%   x:       speech signal
%   fs:      sample rate (function will resample to 16 kHz)
%   num_sin: number of selected channels (i.e., N in N-of-M strategy)
%
% output parameters:
%   y:      vocoded speech signal
%   Y_bin:  TF-matrix with channel selections and amplitudes
%   X:      cochleagram of speech 
%   Y:      cochleagram of vocoded speech (without reconstruction errors)
%   Yr:    	cochleagram of vocoded speech (with reconstruction errors)
%
% [1] CH Taal, RC Hendriks, R Heusdens, 'Matching Pursuit for Channel  
%     Selection in Cochlear Implants Based on an Intelligibility Metric',  
%     Eusipco Proceedings, pp 504 - 508, 2012.
%
% Copyright 2012: Cees Taal, KTH, Sound&Image Processing Lab, Stockholm, 
% Sweden. The software is free for non-commercial use. This program comes 
% WITHOUT ANY WARRANTY.
%
% contact:
% chtaal@gmail.com
% www.ceestaal.nl

addpath('general');

%% dictionary items will be plotted when TRUE 
debug = 1;

%% resample signals if other samplerate is used than fs
fs      = 16000;

if fs_signal ~= fs
    x	= resample(x, fs, fs_signal);
end

%% add some noise at 100 dB SNR to prevent numerical problems and make sure we work with column vectors
x     	= addnoise(x(:), 100);

%% parameters of CI processor
lap     = 2;                                % 1/overlap 
N       = round(((8)/1000*fs/lap))*lap;     % window length
K       = N/lap;                            % hop size
f_min   = 150;                              % center frequency of first band
f_max   = 5000;                             % center frequency of last band
M       = 20;                               % number of channels

%% apply pre-emphasis filter. (this should not matter this much since the STOI measure is also whitening the speech)
hp      = get2php(1200, fs);    % 1200 Hz cutoff, one-pole highpass filter
x       = filter(hp, x);

%% initialize filterbank of auditory model
N_ms        = 16;                                       % window size in ms
fb_N    	= round(N_ms/1000*fs/2)*2;                  % window size in samples
fb_K        = fb_N/2;                                   % hop size
fb_M       	= 32;                                       % number of auditory filters
[H fb_cf] 	= gt_getfb(150, 5000, fs, fb_N, fb_M);      % filterbank magnitude response
        
%% intelligibility distance measure (STOI) parameters
st_N  = 384/(N_ms/2);                                   % window analysis length

%% Band importance functions, e.g. as in SII. (this can be ignored since i set them all to 1)
bif     = ones(size(fb_cf));

%% sinusoidal vocoder parameters
vc_N    = N;
vc_K    = K;
vc_M    = M;
vc_cf   = exp(linspace(log(f_min), log(f_max), vc_M+2));
vc_cf   = vc_cf(2:(end-1));
vc_win  = hanning(vc_N);

%% calculate internal representation of unprocessed signal
X           = gt_analysis(x, H, fb_N).^2;

%% generate sinusoidal carrier
carrier     = zeros(length(x), vc_M);   % this one is modulated in the actual vocoder
carrier2    = zeros(vc_N, vc_M);        % this one will store the dictionary elements (average IR for windowed sinusois)

for i =1:length(vc_cf)
    carrier(:, i)   = cos(vc_cf(i)*2*pi*(0:length(x)-1)/fs);
    carrier2(:, i)  = vc_win'.*exp(sqrt(-1)*vc_cf(i)*2*pi*(0:vc_N-1)/fs)/sqrt(2);
end

%% matching pursuit parameters
numElements 	= num_sin;

%% fill the dictionary
fb_frames 	= 1:fb_K:(length(x)-fb_N);
vc_frames   = 1:vc_K:(length(x)-vc_N);
ii          = (fb_N-vc_K):-vc_K:fb_K;
st_i        = 1:st_N;
bfr         = zeros(fb_M*st_N, vc_M, length(ii));

for i = 1:length(ii)
    if debug
        figure;
    end
    len         = length(fb_frames(st_i(1)):(fb_frames(st_i(end))+fb_N-1));
    
    for j = 1:vc_M
        te2             = [zeros(len-ii(i)-length(carrier2(:, j)), 1); carrier2(:, j); zeros(ii(i), 1)];
        TE2             = gt_analysis(te2, H, fb_N).^2;
        bfr(:, j, i)    = TE2(:);
        if debug
            subplot(5, 4, j); 
            imagesc(10*log10(vec2tf(TE2, fb_M))); 
            colorbar off;
            set(gca, 'xticklabel', '');
            set(gca, 'yticklabel', '');
        end
    end
end

%% apply MP algorithm
mp_a	= zeros(size(X, 2), numElements+1);
mp_ii	= zeros(size(X, 2), numElements+1);
mp_d	= zeros(size(X, 2), numElements+1);
Y       = zeros(size(X));
y       = zeros(size(x));
Y_bin   = zeros(vc_M, length(vc_frames));
cnt     = 1;

for i = 1:length(vc_frames)
    ii      = vc_frames(i):(vc_frames(i)+vc_N-1);
    st_i    = find((ii(end)>=(fb_frames)&ii(end)<=(fb_frames+fb_N-1))==1);
    
    if isempty(st_i)
        break;
    end
    
    st_i    = st_i(end)-st_N+1:st_i(end);

    if st_i(1)>0
        jj      = fb_frames(st_i(1)):(fb_frames(st_i(end))+fb_N-1);
        bf      = bfr(:, :, mod((cnt)-1, fb_N/vc_N)+1);
        cnt     = cnt+1;
        
        % iterate all dictionary elements and determine distortions and optimal amplitudes
        X_seg  	= X(:, st_i);                                              % region with length N of clean TF-units for all j
        mn      = repmat(mean(X_seg, 2), [1 st_N]);
        A       = repmat(bif'./sqrt(sum(abs(X_seg-mn).^2, 2)), [1 st_N]);
        Rx      = X_seg-Y(:, st_i);    % residual

        mp_a(st_i(end), 1) 	= nan;
        mp_ii(st_i(end), 1)	= nan;
        mp_d(st_i(end), 1)	= sum((A(:).*X_seg(:)).^2);
        
        for j = 1:numElements
            a_kk    = zeros(vc_M, 1);
            d_kk    = zeros(vc_M, 1);
            
            for k = 1:vc_M 
                a_kk(k)     = (A(:).*Rx(:))'*(A(:).*bf(:, k))/sum((A(:).*bf(:, k)).^2);
                d_kk(k)     = sum((A(:).*(Rx(:)-a_kk(k).*bf(:, k))).^2);
            end
            [min_dd min_ii]     = min(d_kk);
            
            mp_a(st_i(end), j+1)    = a_kk(min_ii);
            if ~isnan(mp_a(st_i(end), j+1))
                mp_ii(st_i(end), j+1)   = min_ii;
                mp_d(st_i(end), j+1)    = min_dd;

                Y(:, st_i)          	= Y(:, st_i)+vec2tf(a_kk(min_ii).*bf(:, min_ii), fb_M);
                Y_bin(min_ii, i)        = sqrt(abs(a_kk(min_ii))).*sign(a_kk(min_ii));
                Rx                      = X(:, st_i)-Y(:, st_i);
                te                      = sqrt(abs(a_kk(min_ii))).*[zeros(length(jj(1):(ii(1)-1)), 1); carrier(ii, min_ii).*vc_win; zeros(length((ii(end)+1):jj(end)), 1)];
                y(jj)                   = y(jj)+te;
            end
        end
    end
end

%% re-analyze speech signal to have a clue about reconstruction errors
Yr           = gt_analysis(y, H, fb_N).^2;

%%
if debug
    mx  = max(10*log10(X(:)));
    mn  = mx - 50;

    figure;
    subplot(4, 1, 1);
    tfplot2(10*log10(X), mn, mx);
    title('clean speech');

    subplot(4, 1, 2);
    tfplot2(10*log10(Y_bin.*(Y_bin>0)), mn, mx);
    title('channel selections');

    subplot(4, 1, 3);
    tfplot2(10*log10(Y.*(Y>0)), mn, mx);
    title('vocoded speech');

    subplot(4, 1, 4);
    tfplot2(10*log10(Yr), mn, mx);
    title('vocoded speech (w. reconstruction errors)');
end

