function y = addnoise(x, snr)

% addnoise(x, snr)

a   = std(x)./(10^(snr/20));
n   = randn(size(x));
n   = n./std(n);
n   = n*a;

y   = x+n;