function y = vec2tf(x, M)

y       = zeros(M, length(x(:))/M);
y(:)    = x;

