function y = dfactorial(x)

y = prod(x:-2:1);