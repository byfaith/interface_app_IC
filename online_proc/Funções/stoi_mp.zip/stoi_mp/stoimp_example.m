clear all

[x fs]              = wavread('SA2.wav');
x                   = x(:);
x                   = [zeros(fs, 1); x];
[y Y_bin X Y Yr]  	= stoi_mp(x(:), fs, 6);

soundsc(y, fs);
soundsc(x, fs);
